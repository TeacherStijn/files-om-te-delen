window.onload = function() {

    let fouten = [];
    console.clear();

    let karakter = {
        naam: 'Crystal',
        level: 60,
        klasse: 'Mage',
        ras: 'Gnome',
        server: 'aggamagan'
    }

    console.log(karakter.level);
    karakter.naam = 'Kriebels';
    document.body.innerHTML += karakter.naam;

    let naam = 'Qwin';

    if (naam == 'Qwin') {
        console.log('Alles goed!');
    } else if (naam == 'Jan') {
        console.log('Oops, naam is niet Jan, maar moet zijn: ' + naam);
    } else if (naam == 'Mandy') {
        console.log('Mandy');
    } else {
        console.log('Weer een andere naam');
    }


    let kat = {
        naam: 'Poesnaam',
        ras: 'Britse Korthaar',
        kleur: 'Bruin'
    }

    let kip = {
        naam: 'Tok',
        ras: 'Barneveldse Kip',
        kleur: 'Wit'
    }

    let hond = {
        naam: 'Woef',
        ras: 'Labrador',
        kleur: 'Zwart'
    }


    let dierObjecten = [kip, kat, hond];

    let dieren = [kip, kat, 'Fantasieschaap', 'Fantasievarken', 'Eenhoorn'];



    function zoekDier(invoer) {
            for (let dier of dierObjecten) {
                if (dier.naam == invoer) {
                    return dier;
                }
            }
    }

    console.log('Gevonden: ' + zoekDier('Woef').naam);




    console.group('Dieren met While loop');

    let teller = 0;
    while (teller < dieren.length) {

        if (typeof dieren[teller] == 'object') {
            console.log(dieren[teller].ras);
        } else {
            console.log(dieren[teller]);
        }

        console.log();
        teller++;
    }

    console.groupEnd();

    console.group('Dieren met For loop');

    for (let i=0; i<dieren.length; i++) {
        console.log(dieren[i]);
    }

    for (let dier of dieren) {
        console.log(dier);
    }

    console.groupEnd();

    console.group('Monitor testjes');

    let monitor = {
        display: 'ips',
        diagonaal: '24inch',
        merk: 'Samsung'
    }

    console.log(monitor.diagonaal);
    console.log(monitor['diagonaal']);

    console.log('//////////////////////////////////////');

    for (let eigenschap in monitor) {
        console.log(eigenschap);
        console.log(monitor[eigenschap]);
    }

    console.groupEnd();


    let prijzen = [10, 3.5, 2.7, 8];
    let totaal = 0;

    /*
    totaal = 10 + 3.5 + 2.7 + 8;
    totaal = prijzen[0] + prijzen[1] + prijzen[2] + prijzen[3];
    */


    /*
    totaal = totaal + 10;
    console.log(totaal);

    totaal = totaal + 3.5;
    console.log(totaal);

    totaal = totaal + 2.7;
    console.log(totaal);

    totaal = totaal + 8;
    console.log(totaal);
    */

    for (let i=0; i<prijzen.length; i++) {
        totaal = totaal + prijzen[i];
        console.log(totaal);
    }


    for (let prijs of prijzen) {
        totaal = totaal + prijs;
        console.log(totaal);
    }



    // Manier één, zonder return:
    function telop(a, b) {
        console.log(a+b);
    }

    telop(3,5);

    // Manier twee, met return:
    function telop2(a,b) {
        return a+b;
    }

    let resultaat = telop2(8,9);
    console.log(resultaat);



    // 'Bijzonder' met ifjes:
    function telopBijzonder(getal1, getal2, soort){

        if (typeof getal1 == 'number' && typeof getal2 == 'number') {

            if (soort == '+') {
                return getal1 + getal2;
            } else if (soort == '-') {
                return getal1 - getal2;
            } else if (soort == '*') {
                return getal1 * getal2;
            } else {
                return 'Ja hier doen wij niet aan';
            }

        } else {
            throw new Error ('Geen getallen!');
        }
    }

    console.log(telopBijzonder(2,5,'-'));
    console.log(telopBijzonder(2,5,'*'));
    console.log(telopBijzonder(2,5,'lunchtijd'));















    let knop = document.getElementById("btnInvoer");

    knop.addEventListener('click', invoerControle);

    function invoerControle(){
        alert('invoer wordt gecontroleerd');
    }








    console.clear();





  let auto = {
        merk: 'toyota',
        type: 'avensis',
        starten: function() {
            console.log('De ' + this.merk  + ' start; broem broemm');
        }
  }

  auto.starten();















    let prijzen2 = [10, 3.5, 2.7, 8];
    let totaal2 = 0;

    /*
    Array.prototype.voorIeder = function(invoer){
        for (let item of this){
                invoer(item);
        }
    }

    prijzen2.voorIeder(maakTotaal);
    */




    prijzen2.forEach(doeIets);

    function doeIets (input) {
        console.log(input*2);
    }

    prijzen2.forEach(function (input) {
        console.log(input*2);
    });

    prijzen2.forEach(input=>console.log(input*2));










    let prijzen3 = prijzen2.map(function keer2 (inp){
        return inp*2;
    });

    /*
    let prijzen3 = prijzen2.map(inp=>inp*2);
    */

    console.log(prijzen3);





    function optellen () {
        console.log(5+8);
    }

    optellen();



    function optellen2 (a,b) {
        console.log(a+b);
    }

    optellen2(5,8);




    let mijnJSON = `{
        "naam": "pen",
        "prijs": 1.5
    }`;

    let mijnJS = JSON.parse(mijnJSON);
    alert(mijnJS.naam);

    mijnJSON = JSON.stringify(mijnJS);
    localStorage.setItem('artikel', mijnJSON);








    fetch('http://hp-api.herokuapp.com/api/characters').then(
        input=>input.json()
    ).then(
        // hier heb je je data
        function(data) {

            let resultaat = data.find(el=>el.species=='dragon');
            alert(resultaat.name);

            document.body.innerHTML += `
                <h2>${data[0].name}</h2>
                <img src="${data[0].image}" >
            `
        }
    )

    // hier heb je NIET je data






















    x=3;
    // hier wordt x per ongeluk 4?
    x=4;
    if (x==4) {
      fouten.push(new Error("oopsie op tijdstip: " + new Date().getTime()));
    }

    localStorage.setItem('fouten', fouten);
}










